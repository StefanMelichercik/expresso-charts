POKER RANDOMIZER  v1.5
======================

A random number that follows your mouse cursor, above every window.

START
-----
Unzip this file (right-click -> Extract All) and double-click
PokerRandomizer.exe. Nothing to install: it runs on the .NET Framework
that is already part of Windows 10 / 11.

The first time, Windows may show a blue "Windows protected your PC"
window. Click "More info", then "Run anyway". This appears only because
the file is not digitally signed.

ACTIVATION
----------
On the first start the app shows your MACHINE CODE (XXXX-XXXX-XXXX-XXXX).

  1. Enter this machine code at checkout when you buy Poker Randomizer
     (or email it to us if you already bought it).
  2. You receive your activation code by email, usually within 24 hours.
  3. Paste it into the app and click ACTIVATE.

The activation is for one computer and never expires. It works offline.
New computer or reinstalled Windows? Email us the new machine code:
support@expressocharts.com

WHEN THE NUMBER CHANGES
-----------------------
Settings, row NEW NUMBER:

  EVERY X SEC     a new number every X seconds
  ON LEFT CLICK   a new number after each left click anywhere

In ON LEFT CLICK mode the number changes only when you release the
left mouse button, so the number you decided on stays on screen during
the whole action. Clicks in the settings window don't count.

You can also ask for a new number at any time with Ctrl+Alt+R.

CONTROLS
--------
Icon in the system tray next to the clock: right-click = menu,
double-click = settings.

  Ctrl+Alt+R   new number now
  Ctrl+Alt+S   settings
  Ctrl+Alt+H   hide / show
  Ctrl+Alt+X   exit

STYLES
------
  MINIMAL  clean number with a dark outline
  NEON     glowing number on a soft dark background
  HUD      number in a targeting frame, the most visible

SETTINGS
--------
The settings window has a live preview (dark table on the left, green
on the right). Click the preview for a new number. You can change:

  - mode: every X seconds / on left click
  - how often the number changes (0.2 to 600 seconds)
  - range of numbers (default 1 to 100)
  - style, font and size
  - number colour and glow colour (6 presets + your own with +)
  - opacity
  - distance from the cursor
  - leading zero (07 instead of 7)
  - dark outline (easier to read on light tables)
  - countdown bar
  - start with Windows

SAVE keeps the changes, CANCEL undoes them, RESET restores the defaults.
Settings are saved in %APPDATA%\PokerRandomizer\settings.ini

COLOUR BY RANGE (optional)
--------------------------
Tick "Colour the number by range" and click EDIT RANGES. Each range is
"from - to" with its colour, for example:

  #1   1 - 20    pink
  #2  21 - 40    yellow
  #3  41 - 60    green

+ ADD RANGE adds a range (up to 10), x removes it. Numbers outside every
range keep the normal colour. If two ranges overlap, the higher one in
the list wins.

NOTES
-----
- Clicks pass through the number, and it never steals focus from your
  table.
- ON LEFT CLICK mode watches clicks system-wide (only watches, never
  changes them). If your poker site has strict rules about such
  programs, use EVERY X SEC mode.
- If your poker client runs as administrator, run this app as
  administrator too (right-click -> Run as administrator), otherwise
  Windows won't let it draw above the client.
- Poker Randomizer only shows a random number. It does not read the
  table or play for you. Always check the rules of the site you play on.
